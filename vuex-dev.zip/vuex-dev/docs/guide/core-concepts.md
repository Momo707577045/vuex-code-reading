# Core Concepts

We will be learning the core concepts of Vuex in these chapters. They are:

- [State](state.md)
- [Getters](getters.md)
- [Mutations](mutations.md)
- [Actions](actions.md)
- [Modules](modules.md)

A deep understanding of all these concepts is essential for using vuex.

Let's get started.
