// 便捷辅助函数
/**
 * Reduce the code which written in Vue.js for getting the state.
 * @param {String} [namespace] - Module's namespace
 * @param {Object|Array} states # Object's item can be a function which accept state and getters for param, you can do something for state and getters in it.
 * @param {Object}
 */
export const mapState = normalizeNamespace((namespace, states) => {
  // state是映射关系，namespace是命名空间，但该命名空间不一定有
  const res = {} // 返回的是一个对象
  normalizeMap(states).forEach(({ key, val }) => {
    res[key] = function mappedState() { // 因为该mapState只设计放在computed中使用，所以返回的是一个function。即让vue依赖本函数的内容，进行数值动态变化
      let state = this.$store.state
      let getters = this.$store.getters
      if (namespace) { // 获取带命名空间的模块
        const module = getModuleByNamespace(this.$store, 'mapState', namespace)
        if (!module) {
          return
        }
        state = module.context.state // 调用具体模块的state，但其实质上调用的是vuex实例的_state
        getters = module.context.getters
      }
      return typeof val === 'function' // 兼容函数操作和普通对象或数组的引用
        ? val.call(this, state, getters) // 传入是函数，则将state与getters作为参数传入，自由组合，相当于getter的用法，特立的getter
        : state[val]
    }
    res[key].vuex = true  // mark vuex getter for devtools
  })
  return res
})

/**
 * mutation是函数形式，所以返回的也是函数，即返回独立的函数，而不需要vuex去引用
 * @param {String} [namespace] - Module's namespace
 * @param {Object|Array} mutations # Object's item can be a function which accept `commit` function as the first param, it can accept anthor params. You can commit mutation and do any other things in this function. specially, You need to pass anthor params from the mapped function.
 * @return {Object}
 */
export const mapMutations = normalizeNamespace((namespace, mutations) => {
  const res = {}
  normalizeMap(mutations).forEach(({ key, val }) => {
    res[key] = function mappedMutation(...args) {
      let commit = this.$store.commit // 因为Mutation实际上是需用通过commit去触发的，所以返回的是commit
      if (namespace) {
        const module = getModuleByNamespace(this.$store, 'mapMutations', namespace)
        if (!module) {
          return
        }
        commit = module.context.commit
      }
      // 可以将val传入一个函数，函数的第一个参数将被填充为绑定了this.$store的commit方法，方便在函数中调用
      return typeof val === 'function'
        ? val.apply(this, [commit].concat(args))
        // apply(this.$store是绑定vuex去调用，[val].concat(args)是将type作为第一个参数，其余作为后续参数，传递到commit函数使用
        : commit.apply(this.$store, [val].concat(args))
    }
  })
  return res
})

/**
 * Reduce the code which written in Vue.js for getting the getters
 * @param {String} [namespace] - Module's namespace
 * @param {Object|Array} getters
 * @return {Object}
 */
export const mapGetters = normalizeNamespace((namespace, getters) => {
  const res = {}
  normalizeMap(getters).forEach(({ key, val }) => {
    val = namespace + val
    res[key] = function mappedGetter() { //  getter和state一样，都放在computed，所以返回的是函数。getter相当于vuex内部的统一处理函数
      if (namespace && !getModuleByNamespace(this.$store, 'mapGetters', namespace)) {
        return
      }
      if (process.env.NODE_ENV !== 'production' && !(val in this.$store.getters)) {
        console.error(`[vuex] unknown getter: ${val}`)
        return
      }
      // 这里由于特殊的原因，直接从$store中获取并返回getter，而没有从模块的content中获取？Momo
      return this.$store.getters[val]
    }
    // mark vuex getter for devtools
    res[key].vuex = true
  })
  return res
})

/**
 * Reduce the code which written in Vue.js for dispatch the action
 * @param {String} [namespace] - Module's namespace
 * @param {Object|Array} actions # Object's item can be a function which accept `dispatch` function as the first param, it can accept anthor params. You can dispatch action and do any other things in this function. specially, You need to pass anthor params from the mapped function.
 * @return {Object}
 */
export const mapActions = normalizeNamespace((namespace, actions) => {
  const res = {}
  normalizeMap(actions).forEach(({ key, val }) => {
    res[key] = function mappedAction(...args) {
      let dispatch = this.$store.dispatch // 因为Action实际上是需用通过dispatch去触发的，所以返回的是dispatch
      if (namespace) {
        const module = getModuleByNamespace(this.$store, 'mapActions', namespace)
        if (!module) {
          return
        }
        dispatch = module.context.dispatch
      }
      console.log(`${key}:${val}  ${ typeof val}`)

      return typeof val === 'function'
        ? val.apply(this, [dispatch].concat(args))
        : dispatch.apply(this.$store, [val].concat(args))
    }
  })
  return res
})

/**
 * 根据命名空间，返回特定的辅助函数。其本质是往各个辅助函数中添加了命名空间前缀
 * 生成函数，且函数的第一个参数已经被设置好，设置namespace，后续使用时，从参数的第二个开始填充
 * @param {String} namespace
 * @return {Object}
 */
export const createNamespacedHelpers = (namespace) => ({
  mapState: mapState.bind(null, namespace),
  mapGetters: mapGetters.bind(null, namespace),
  mapMutations: mapMutations.bind(null, namespace),
  mapActions: mapActions.bind(null, namespace)
})

/**
 * 解析map内容，兼容数组写法和对象写法。带命名空间的模块不能直接使用辅助函数的原因，因为key和value值是相同的。
 * 所以只能分开写key和value
 * normalizeMap([a, b, c]) => [ { key: a, val: a }, { key: b, val: b }, { key: c, val: c } ]
 * normalizeMap({a: 1, b: 2, c: 3}) => [ { key: 'a', val: 1 }, { key: 'b', val: 2 }, { key: 'c', val: 3 } ]
 * @param {Array|Object} map
 * @return {Object}
 */
function normalizeMap(map) {
  return Array.isArray(map)
    ? map.map(key => ({ key, val: key }))
    : Object.keys(map).map(key => ({ key, val: map[key] }))
}

/**
 * 用于适配单纯的map写法和带上命名空间的写法
 * 带上命名空间的写法在createNamespacedHelpers中使用，
 * @param {Function} fn
 * @return {Function}
 */
function normalizeNamespace(fn) {
  return (namespace, map) => {
    if (typeof namespace !== 'string') {
      map = namespace
      namespace = ''
    } else if (namespace.charAt(namespace.length - 1) !== '/') { // 补「/」
      namespace += '/'
    }
    return fn(namespace, map)
  }
}

/**
 * 通过命名空间带上前缀的完整路径获取具体的模块
 * @param {Object} store
 * @param {String} helper
 * @param {String} namespace
 * @return {Object}
 */
function getModuleByNamespace(store, helper, namespace) {
  const module = store._modulesNamespaceMap[namespace]
  if (process.env.NODE_ENV !== 'production' && !module) {
    console.error(`[vuex] module namespace not found in ${helper}(): ${namespace}`)
  }
  return module
}
